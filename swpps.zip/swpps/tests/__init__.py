"""Tests for SWPPS package."""
